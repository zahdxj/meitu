<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:66:"E:\phpStudy\WWW\thinkphp5/application/admin\view\goods\addCat.html";i:1479546048;s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479694667;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/main.css" />

</head>
<body>

<!--Header-part-->
<div id="header">
    <h1>后台管理系统</h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li id="profile-messages" >
            <a title="" href="<?php echo url('index/index'); ?>">
                <span class="glyphicon glyphicon-user white"></span>
                <span class="text white">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <span class="glyphicon glyphicon-share-alt white"></span> 
                <span class="text white">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><span class="glyphicon glyphicon-th"></span><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content" data-controller="goods" data-page="addCat">
	<div id="content-header" class="content-extra">
  		<div id="breadcrumb"> 
  			<a href="" title="首页" class="tip-bottom">
  				<span class="glyphicon glyphicon-home"></span>首页
  			</a>
  			<a href="" class="tip-bottom">商品管理</a> 
  			<a href="" class="current"><?php echo $title; ?></a> 
  		</div>
	</div>
    <div class="content">
	<div class="content-top">
		<a class="btn btn-primary white" href="<?php echo url('category'); ?>" role="button">
			<strong>商品分类</strong>
		</a>
	</div>
    </div>
	<div class="content-left">
		<form action="" method="post" name="catform" onsubmit="return checkform()" class="form-horizontal" role="form">
			<div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">分类名称：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="text" name="cat_name" value="<?php if(isset($info)): ?><?php echo $info['cat_name']; endif; ?>" class="form-control" onblur="chkname(this)"/>
		      	</div>
		      	<span id="sp1" style="color:red;" class="col-sm-9 col-sm-offset-3"></span>
		    </div>
			<div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">上级分类：</label>
		    	</div>
		    	<div class="col-sm-9">
                    <select name="pid">
                        <option value="" >顶级分类</option>
                        <?php if(is_array($list) || $list instanceof \think\Collection): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <option value='<?php echo $vo['cat_id']; ?>' <?php if(isset($info['pid']) && ($vo['cat_id'] == $info['pid'])): ?>selected<?php endif; ?> ><?php echo returnspace($vo['level']); ?><?php echo $vo['cat_name']; ?></option>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
		      	</div>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">分类描述：</label>
		    	</div>
		    	<div class="col-sm-9">
		    		<textarea class="form-control" name="cat_desc" rows="6" cols="30" style="resize:none;"><?php if(isset($info)): ?><?php echo $info['cat_desc']; endif; ?></textarea>
		    	</div>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">是否显示：</label>
		    	</div>
		    	<div class="col-sm-9">
                    <select name="is_show">
                        <option value="1"<?php if(isset($info) && $info['is_show'] == 1): ?>selected<?php endif; ?>>是</option>
                        <option value="0"<?php if(isset($info) && $info['is_show'] == 0): ?>selected<?php endif; ?>>否</option>
                    </select>
		    	</div>
		    </div>
		    <div class="form-group login-margin">
			    <div class="col-sm-offset-3 col-sm-9">
                    <input type="hidden" name="cat_id" value="<?php if(isset($info)): ?><?php echo $info['cat_id']; endif; ?>"/>
			        <button class="btn btn-primary" type="submit" name="submit"  id="sub">确定</button>
			        <button class="btn btn-white" type="reset" name="reset" style="margin-left:20px;">重置</button>
			    </div>
			</div>
		</form>
	</div>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">技术支持：南京微沐软件科技有限公司</div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/common.js"></script> 


</body>
</html>