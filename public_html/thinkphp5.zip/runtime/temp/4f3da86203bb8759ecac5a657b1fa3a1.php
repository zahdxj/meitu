<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:62:"E:\phpStudy\WWW\thinkphp5/application/admin\view\ad\index.html";i:1479697232;s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479694667;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/main.css" />

</head>
<body>

<!--Header-part-->
<div id="header">
    <h1>后台管理系统</h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li id="profile-messages" >
            <a title="" href="<?php echo url('index/index'); ?>">
                <span class="glyphicon glyphicon-user white"></span>
                <span class="text white">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <span class="glyphicon glyphicon-share-alt white"></span> 
                <span class="text white">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><span class="glyphicon glyphicon-th"></span><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content" data-controller="ad" data-page="index">
	<div id="content-header"  class="content-extra">
	  	<div id="breadcrumb"> 
	  		<a href="" title="首页" class="tip-bottom">
	  			<span class="glyphicon glyphicon-home"></span>首页
	  		</a>
	  		<a href="" class="tip-bottom">广告管理</a> 
	  		<a href="" class="current">首页轮播图</a> 
	  	</div>
	</div>
	<div class="content content_ad">
        <form action="" method="post" name="addform" enctype="multipart/form-data" onsubmit="return checkform()" role="form" class="form-horizontal">
			<table id="tb" class="table table-hover table-bordered text-center" style="width: 90%">
				<tr class="bg-info">
					<td>操作</td>
					<td width="330">图片</td>
					<td>图片尺寸</td>
					<td>链接地址</td>
					<td>描述</td>
				</tr>
	            <?php if(!empty($banner_list)): if(is_array($banner_list) || $banner_list instanceof \think\Collection): $i = 0; $__LIST__ = $banner_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$banner): $mod = ($i % 2 );++$i;?>
	            <tr id="row_<?php echo $key; ?>">
	                <input type="hidden" name="id[]" value="<?php echo $banner['id']; ?>" />
	                <?php if($key == 0): ?>
					<td><div class="add_btn" onclick="add_row()"></div></td>
	                <td>
						<div class="goods_img_item" id="goods_img_<?php echo $key; ?>">
			    			<div id="imgdiv_<?php echo $key; ?>"><img id="imgShow_<?php echo $key; ?>" width="320" height="180" onclick="$('#up_img_<?php echo $key; ?>').click()" src="__PUBLIC__/<?php echo $banner['img_path']; ?>" /></div><input class="img_input" type="file" id="up_img_<?php echo $key; ?>" name="img_path[]" value="<?php echo $banner['img_path']; ?>"/>
			    		</div>
					</td>
	                <?php else: ?>
					<td><div class="del_btn" onclick="del_row('<?php echo $key; ?>')"></div></td>
	                <td>
						<div class="goods_img_item" id="goods_img_<?php echo $key; ?>">
			    			<div id="imgdiv_<?php echo $key; ?>"><img id="imgShow_<?php echo $key; ?>" width="320" height="180" onclick="$('#up_img_<?php echo $key; ?>').click()" src="__PUBLIC__/<?php echo $banner['img_path']; ?>" /></div><input class="img_input" type="file" id="up_img_<?php echo $key; ?>" name="img_path[]" value="<?php echo $banner['img_path']; ?>"/>
			    		</div>
					</td>
	                <?php endif; ?>
					<td>750*360</td>
					<td><textarea name="img_url[]" rows="3" style="width: 100%"><?php echo $banner['img_url']; ?></textarea></td>
					<td><textarea name="img_desc[]" rows="3" style="width: 100%"><?php echo $banner['img_desc']; ?></textarea></td>
				</tr>
	            <?php endforeach; endif; else: echo "" ;endif; else: ?>
	            <tr id="row_0">
					<td><div class="add_btn" onclick="add_row()"></div></td>
	                <td>
						<div class="goods_img_item" id="goods_img_0">
			    			<div id="imgdiv_0"><img id="imgShow_0" width="320" height="180" onclick="$('#up_img_0').click()" src="__IMAGES__/plus2.jpg" /></div><input class="img_input" type="file" id="up_img_0" name="img_path[]" />
			    		</div>
					</td>
					<td>640*360</td>
					<td><input type="text" name="img_url[]"></td>
					<td><input type="text" name="img_desc[]"></td>
				</tr>
	            <?php endif; ?>
			</table>
            <div class="form-group login-margin">
			    <div class="col-sm-offset-3 col-sm-9">
                        <button class="btn btn-primary" type="submit" id="submit" name="submit">确定</button>
			        <button class="btn btn-white" type="reset"  style="margin-left: 20px;">重置</button>
			    </div>
			</div>
        </form>
	</div>
</div>
<input type="hidden" name="count" value="<?php echo $count; ?>">


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">技术支持：南京微沐软件科技有限公司</div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/common.js"></script> 


<script charset="utf-8" src="__JS__/uploadPreview.js"></script>
<script charset="utf-8" src="__JS__/ad.js"></script>

</body>
</html>