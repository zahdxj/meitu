<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:69:"E:\phpStudy\WWW\thinkphp5/application/home\view\goods\goods_info.html";i:1479804590;s:64:"E:\phpStudy\WWW\thinkphp5/application/home\view\public\base.html";i:1479804427;s:67:"E:\phpStudy\WWW\thinkphp5/application/home\view\public\contact.html";i:1479548245;}*/ ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=3, minimum-scale=1, user-scalable=no">
<meta name="format-detection" content="email=no"/>
<title>美图商城</title>
<link href="__HOME__/css/weui.css" rel="stylesheet" type="text/css" />
<link href="__HOME__/css/swiper-3.4.0.min.css" rel="stylesheet" type="text/css" />
<link href="__HOME__/css/home.css" rel="stylesheet" type="text/css" />
</head>
<body ontouchstart>
	<div class="ui_fixed">
	    <div class="weui_cell ui_navbar">
            <div class="weui_cell_hd">
                <img src="__HOME__/images/category.png" id="show"/>
                <span class="category">分类</span>
            </div>
            <div class="weui_cell_bd weui_cell_primary">
                <div class="weui_search_bar" id="search_bar">
                    <form class="weui_search_outer" action="<?php echo url('Goods/goods_list'); ?>" method="get" name="searchForm">
                        <div class="weui_search_inner">
                            <input type="search" name="keywords" class="weui_search_input" id="search_input" placeholder="搜索你想要的商品名称" required/>
                            <img src="__HOME__/images/search.png" onclick="submitForm()"/>
                        </div>
                    </form>
                </div>
            </div>
        </div>
	</div>
	<div class="mask"></div>
	<div class="weui_cells ui_animate">
        <?php if(is_array($cat_list) || $cat_list instanceof \think\Collection): $i = 0; $__LIST__ = $cat_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <a href="<?php echo url('Goods/goods_list',array('cat_id'=>$vo['cat_id'])); ?>" class="weui_cell">
            <div class="weui_cell_bd weui_cell_primary">
                <p><?php echo $vo['cat_name']; ?></p>
            </div>
        </a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>


<div class="container" data-controller="goods" data-page="goods_info">
	<!-- 商品轮播 -->
    <div class="swiper-container">
        <div class="swiper-wrapper goods-swiper">
            <?php if(is_array($goods_gallery) || $goods_gallery instanceof \think\Collection): $i = 0; $__LIST__ = $goods_gallery;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <div class="swiper-slide"><img src="__PUBLIC__/<?php echo $vo['img_url']; ?>" /></div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <div class="swiper-pagination"></div>
    </div>
    <div class="ui_cell">
        <div class="ui_tips">宝贝为拍摄，实物更漂亮</div>
        <div class="ui_title">
        	<p><?php echo $goods_info['goods_name']; ?></p>
        	<p>价格：<font color="#e92076"><?php echo $goods_info['goods_price']; ?>元</font></p>
        </div>
    </div>
    <div class="ui_cell">
    	<div class="weui_cell ui_service">
            <div class="weui_cell_hd">
            	<img src="__HOME__/images/qrcode.jpg" alt="">
            </div>
            <div class="weui_cell_bd weui_cell_primary">
            	<p>【<font color="#e92076">推荐客服</font>】甜甜</p>
            	<p>微信号：123456999（长按复制）</p>
            	<div>和真诚阳光自信的甜甜做朋友，站在您的角度帮您挑选最合适的宝贝</div>
            </div>
        </div>
    </div>
    <div class="ui_cell">
        <a href="<?php echo $ad1['ad_link']; ?>" title=""><img src="__PUBLIC__/<?php echo $ad1['ad_img']; ?>" alt=""></a>
    </div>
    <div class="ui_cell">
    	<div class="ui_tab">
    		<div class="ui_tab_hd on">宝贝详情</div>
    		<div class="ui_tab_hd">微信客服</div>
    	</div>
    	<!-- 宝贝详情 -->
    	<div class="ui_cell ui_tab_bd p10">
    		<div class="ui_tab_ginfo">
                <article class="weui_article">
                    <section><?php echo $goods_info['goods_info']; ?></section>
                </article>
    		</div>

	        <div class="weui_btn_area ui_btn">
		        <a class="weui_btn weui_btn_primary btn_unfold" href="javascript:" id="btn_unfold">查看详细</a>
		    </div>
    	</div>
    	<!-- 微信客服 -->
    	<div class="ui_cell ui_tab_bd hide">
            <!-- 客服部分 -->
<div class="ui_cell" align="center">
	<p>热线电话：<font color="#e92076">400-888-7189</font>（点击拨打）</p>
</div>
<!-- 客服二维码列表 -->
<div class="ui_cell ui_qrcodes">
    <?php if(is_array($contact_list) || $contact_list instanceof \think\Collection): $i = 0; $__LIST__ = $contact_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
	<div class="ui_col_3">
		<div class="ui_qrcodes_e">
			<img src="__PUBLIC__/<?php echo $vo['weixin_img']; ?>" alt="">
			<p><?php echo $vo['contact_name']; ?></p>
		</div>
	</div>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<!-- 广告 -->
<div class="ui_cell">
	<a href="<?php echo $ad2['ad_link']; ?>" title=""><img src="__PUBLIC__/<?php echo $ad2['ad_img']; ?>" alt=""></a>
</div>
<!-- / 客服部分 -->
    	</div>
    	<div class="ui_cell ui_offer">
    		<div class="ui_row">
	    		<div class="ui_col_4">
                    <a href="<?php echo url('About/index'); ?>" title="">
                        <img src="__HOME__/images/label1.png" alt="">
                        <p>联系我们</p>
                    </a>
	    		</div>
	    		<div class="ui_col_4">
                    <a href="<?php echo url('About/index'); ?>" title="">
                        <img src="__HOME__/images/label2.png" alt="">
                        <p>如何购买</p>
                    </a>
	    		</div>
	    		<div class="ui_col_4">
                    <a href="<?php echo url('About/index'); ?>" title="">
                        <img src="__HOME__/images/label3.png" alt="">
                        <p>售后服务</p>
                    </a>
	    		</div>
	    		<div class="ui_col_4">
                    <a href="<?php echo url('About/index'); ?>" title="">
                        <img src="__HOME__/images/label4.png" alt="">
                        <p>关注我们</p>
                    </a>
	    		</div>
    		</div>
    		<div class="ui_row mt10">
    			<p>良晋数码    版权所有</p>
    			<p>致力于打造一家值得信赖的能承担社会责任的公司！</p>
    		</div>
    	</div>
    </div>
</div>


<!-- footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_default">
    <a href="<?php echo url('index/index'); ?>" class="weui_tabbar_item" id="nav_index">
        <div class="weui_tabbar_icon icon_home"></div>
        <p class="weui_tabbar_label">首页</p>
    </a>
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item" id="nav_contact">
        <div class="weui_tabbar_icon icon_contact"></div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item" id="nav_member">
        <div class="weui_tabbar_icon icon_user"></div>
        <p class="weui_tabbar_label">我的</p>
    </a>
    <a href="<?php echo url('About/aboutus'); ?>" class="weui_tabbar_item" id="nav_about">
        <div class="weui_tabbar_icon icon_about"></div>
        <p class="weui_tabbar_label">关于我们</p>
    </a>
</div>
<!-- 详情页面footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_primary hide">
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/chat.png"/>
        </div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a class="weui_btn weui_btn_default" href="javascript:;" id="showToast">加入收藏夹</a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/star.png"/>
        </div>
        <p class="weui_tabbar_label">收藏夹</p>
    </a>
    <!--BEGIN toast-->
    <div id="toast" style="display: none;">
        <div class="weui_mask_transparent"></div>
        <div class="weui_toast"></div>
    </div>
    <!--end toast-->
</div>
<script src="__HOME__/js/jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/swiper-3.4.0.jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/common.js" type="text/javascript"></script>


<script >
    var urls="{<?php echo url('Goods/addCollect'); ?>}";
    var login_url="<?php echo url('Goods/login'); ?>";
    function submitForm(){
        if(jQuery.trim($("#search_input").val())!=''){
            searchForm.submit();
        }
    }
</script>

</body>
</html>