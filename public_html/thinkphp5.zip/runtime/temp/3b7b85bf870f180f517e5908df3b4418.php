<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\index\index.html";i:1479546592;s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479540020;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/main.css" />

</head>
<body>

<!--Header-part-->
<div id="header">
    <h1>后台管理系统</h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li id="profile-messages" >
            <a title="" href="<?php echo url('index/index'); ?>">
                <span class="glyphicon glyphicon-user white"></span>
                <span class="text white">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <span class="glyphicon glyphicon-share-alt white"></span> 
                <span class="text white">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><span class="glyphicon glyphicon-th"></span><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content" data-controller="index" data-page="index">
    <div id="content-header" class="content-extra">
        <div id="breadcrumb"> 
            <a href="" title="首页" class="tip-bottom">
                <span class="glyphicon glyphicon-home"></span>首页
            </a>
        </div>
    </div>
    <div class="content top-margin">
        <table class="table table-hover table-bordered text-left" style="width: 1063px">
            <tr class="bg-info">
                <td colspan="4"><strong>个人信息</strong></td>
            </tr>
            <tr class="bg-danger">
                <td>管理员名:</td>
                <td class="font-color"><?php echo $admininfo['user_name']; ?></td>
                <td>所属用户组:</td>
                <td class="font-color"><?php echo $admininfo['title']; ?></td>
            </tr>
            <tr class="bg-danger">
                <td>最后登录时间:</td>
                <td><?php echo date('Y-m-d H:i:s',$admininfo['last_login_time']); ?></td>
                <td>最后登录IP:</td>
                <td><?php echo $admininfo['last_login_ip']; ?></td>
            </tr>
        </table>
        <table  class="table table-hover table-bordered table-top text-left" style="width: 1063px">
            <tr class="bg-info">
                <td colspan="4"><strong>系统信息</strong></td>
            </tr>
            <tr class="bg-danger">
                <td>Web服务器</td>
                <td><?php echo $conf['web']; ?></td>
                <td>php版本</td>
                <td><?php echo $conf['phpversion']; ?></td>
            </tr>
            <tr class="bg-danger">
                <td>客户端IP</td>
                <td><?php echo $conf['ip']; ?></td>
                <td>时区设置</td>
                <td><?php echo $conf['timezone']; ?></td>
            </tr>
            <tr class="bg-danger">
                <td>编码</td>
                <td><?php echo $conf['code']; ?></td>
                <td></td>
                <td></td>
            </tr>
        </table>
    </div>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">技术支持：南京微沐软件科技有限公司</div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/common.js"></script> 
</body>
</html>
