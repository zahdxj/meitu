<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\goods\index.html";i:1479696032;s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479694667;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/main.css" />

</head>
<body>

<!--Header-part-->
<div id="header">
    <h1>后台管理系统</h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li id="profile-messages" >
            <a title="" href="<?php echo url('index/index'); ?>">
                <span class="glyphicon glyphicon-user white"></span>
                <span class="text white">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <span class="glyphicon glyphicon-share-alt white"></span> 
                <span class="text white">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><span class="glyphicon glyphicon-th"></span><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content" data-controller="goods" data-page="index">
	<div id="content-header" class="content-extra">
	  	<div id="breadcrumb"> 
	  		<a href="" title="首页" class="tip-bottom">
	  			<span class="glyphicon glyphicon-home"></span>首页
	  		</a> 
	  		<a href="" class="tip-bottom">商品管理</a> 
	  		<span class="current">商品列表</span> 
	  	</div>
	</div>
	<div class="content">
		<div class="content-top">
			<a class="btn btn-primary white"  href="<?php echo url('add'); ?>" role="button">添加商品</a>
		</div>
		<form action="<?php echo url('index'); ?>" method="get" role="form" class="form-inline form-bottom">
			<div class="form-group">
			    <label class="control-label">商品ID：</label>
			    <input type="text" class="form-control" name="search_id" />
		  	</div>
		  	<div class="form-group">
			    <label class="control-label">商品名称：</label>
			    <input type="text" class="form-control"  name="search_name"/>
		  	</div>
		  	<button class="btn btn-primary" type="submit" name="search">搜索</button>
		</form>
		<table class="table table-bordered text-center" style="width: 823px">
			<tr class="bg-info">
				<td>商品ID</td>
				<td>商品名称</td>
				<td>商品分类</td>
				<td>是否上架</td>
				<td>是否首页展示</td>
				<td>排序</td>
				<td>操作</td>
			</tr>
			<?php if(is_array($goods_list) || $goods_list instanceof \think\Collection): $i = 0; $__LIST__ = $goods_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$goods): $mod = ($i % 2 );++$i;?>
	            <tr class="bg-danger">
					<td class="checkbox-style"  style="width: 10%">
						<label class="checkbox">
						  	<input type="checkbox" class="checkbox" name="goods_id[]" value="<?php echo $goods['goods_id']; ?>">
						  	<?php echo $goods['goods_id']; ?>					
						  </label>
					</td>
	            	<td><?php echo $goods['goods_name']; ?></td>
	                <td><?php echo $goods['cat_name']; ?></td>
	                <td>
						<?php if($goods['is_on_sale'] == '1'): ?>是<?php else: ?>否<?php endif; ?>
					</td>
	                <td>
						<?php if($goods['is_show_index'] == '1'): ?>是<?php else: ?>否<?php endif; ?>
					</td>
	                <td>
						<?php echo $goods['sort']; ?>
					</td>
	                <td>
	                	<a href="<?php echo url('edit',array('goods_id'=>$goods['goods_id'])); ?>" class="font-color">编辑
	                	</a>&nbsp;&nbsp;
	                	<a href="javascript:;" class="font-color" onclick="goods_remove('<?php echo url('del'); ?>','<?php echo $goods['goods_id']; ?>')" id="remove_<?php echo $goods['goods_id']; ?>">删除
	                	</a>
	                </td>
	            </tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</table>
		<div class="btn-group">
			<button class="btn btn-default" type="submit" id="plsc" data-url="<?php echo url('del'); ?>">批量删除</button>
			<button class="btn btn-default" type="submit" id="selectAll">全选</button>
			<button class="btn btn-default" type="submit" id="unselect">全不选</button>
			<button class="btn btn-default" type="submit" id="reverse">反选</button>
		</div>
		<div class="page">
			<?php echo $page; ?>
		</div>
    </div>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">技术支持：南京微沐软件科技有限公司</div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/common.js"></script> 


<script charset="utf-8" src="__JS__/goods.js"></script>

</body>
</html>