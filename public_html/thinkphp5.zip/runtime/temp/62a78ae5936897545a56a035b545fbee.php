<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\login\index.html";i:1479375269;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>登录</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/main.css" />
</head>
<body class="body-bg">
	<div class="login-frm">
		<h2 class="text-center">后台管理系统</h2>
		<div class="row">
			<form action="<?php echo url('login/do_login'); ?>" method="post" class="form-horizontal" role="form">
				<div class="form-group login-margin">
			    	<label class="control-label col-sm-3" for="inputname">用户名：</label>
			    	<div class="col-sm-9">
			      		<input type="text" name="user_name" id="inputname" class="form-control" />
			      	</div>
			    </div>
			    <div class="form-group login-margin">
			    	<label class="control-label col-sm-3" for="inputpassword">密码：</label>
			    	<div class="col-sm-9">
			      		<input type="password" name="password" id="inputpassword" class="form-control" />
			      	</div>
			    </div>
				<div class="form-group login-margin">
				    <div class="col-sm-offset-3 col-sm-9">
				        <button class="btn btn-primary" type="submit" name="submit">登录</button>
				        <button class="btn btn-white" type="reset" name="reset">重置</button>
				    </div>
				</div>
		    </form>
	    </div>
	</div>
</body>
</html>
