<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:63:"D:\phpStudy\WWW\thinkphp5/application/admin\view\group\add.html";i:1479087400;s:65:"D:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479104370;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/colorpicker.css" />
<link rel="stylesheet" href="__CSS__/datepicker.css" />
<!-- <link rel="stylesheet" href="__CSS__/uniform.css" />
<link rel="stylesheet" href="__CSS__/select2.css" /> -->
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-wysihtml5.css" />
<link href="__CSS__/font-awesome/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="__CSS__/main.css" />
<!--<script src="__JS__/jquery.js"></script>--> 
</head>
<body>

<!--Header-part-->
<div id="header">
    <h1><a href="dashboard.html">后台</a></h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li  class="dropdown" id="profile-messages" >
            <a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle">
                <i class="icon icon-user"></i>  
                <span class="text">欢迎您,<?php echo \think\Session::get('username'); ?></span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
                <li>
                    <a href="">
                    <i class="icon-user"></i>个人资料</a>
                </li>
                <li class="divider"></li>
                <li>
                    <a href="<?php echo url('login/logout'); ?>">
                    <i class="icon-key"></i>退出
                    </a>
                </li>
            </ul>
        </li>
        <li class="">
            <a title="" href="" target="_blank">
                <i class="icon icon-cog"></i> 
                <span class="text">网站首页</span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <i class="icon icon-share-alt"></i> 
                <span class="text">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    <ul>
    <li class="submenu"><a href=""><i class="icon icon-th"></i><span>管理员管理</span></a>
    <ul style="display:block; ">
            <li><a href="<?php echo url('User/index'); ?>">管理员列表</a></li>
            <li><a href="<?php echo url('Group/index'); ?>">用户组列表</a></li>
            <li><a href="<?php echo url('Group/access'); ?>">权限列表</a></li>
    </ul>
    </li>
   </ul>
</div>
</strong>


<div id="content">
	<div id="content-header">
  		<div id="breadcrumb"> 
  			<a href="" title="首页" class="tip-bottom">
  				<span class="glyphicon glyphicon-home"></span>首页
  			</a>
  			<a href="" class="tip-bottom">管理员管理</a> 
  			<a href="" class="current"><?php echo $title; ?></a> 
  		</div>
  		<h1><?php echo $title; ?></h1>
	</div>
	<div class="content-top">
		<a class="btn btn-primary white" href="<?php echo url('index'); ?>" role="button">
			<strong><span class="glyphicon glyphicon-minus"></span>用户组列表</strong>
		</a>
	</div>
	<div class="content-left">
		<form action="" method="post" name="roleform" onsubmit="return checkform()" class="form-horizontal" role="form">
			<div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">用户组名称：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="text" name="title" value="<?php if(isset($info)): ?><?php echo $info['title']; endif; ?>" class="form-control" onblur="chkname(this)"/>
		      	</div>
		      	<span id="sp1" style="color:red;" class="col-sm-9 col-sm-offset-3"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">用户组描述：</label>
		    	</div>
		    	<div class="col-sm-9">
		    		<textarea class="form-control" name="description" rows="6" cols="30" style="resize:none;"><?php if(isset($info)): ?><?php echo $info['description']; endif; ?></textarea>
		    	</div>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">状态：</label>
		    	</div>
		    	<div class="col-sm-9">
                    <select name="status">
                        <option value="1"<?php if(isset($info) && $info['status'] == 1): ?>selected<?php endif; ?>>启用</option>
                        <option value="0"<?php if(isset($info) && $info['status'] == 0): ?>selected<?php endif; ?>>禁用</option>
                    </select>
		    	</div>
		    </div>
		    <div class="form-group login-margin">
			    <div class="col-sm-offset-3 col-sm-9">
                    <input type="hidden" name="id" value="<?php if(isset($info)): ?><?php echo $info['id']; endif; ?>"/>
			        <button class="btn btn-primary" type="submit" name="submit"  id="sub">确定</button>
			        <button class="btn btn-white" type="reset" name="reset" style="margin-left:20px;">重置</button>
			    </div>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	function checkform(){
		if(roleform.title.value==""){
			$("#sp1").html("用户组名不能为空");
			return false;
		}else{
            $("#sp1").html("");
        }
		return true;
		
	}
	function chkname(obj){
		if(obj.value==""){
			$("#sp1").html("用户组名不能为空");
		}else{
            $("#sp1").html("");
        }
	}
</script>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">  2014 &copy;出自LZ之手 </div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/jquery.ui.custom.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/bootstrap-colorpicker.js"></script> 
<script src="__JS__/bootstrap-datepicker.js"></script> 
<script src="__JS__/jquery.toggle.buttons.html"></script> 
<script src="__JS__/masked.js"></script> 
<script src="__JS__/jquery.uniform.js"></script> 
<script src="__JS__/select2.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/wysihtml5-0.3.0.js"></script> 
<script src="__JS__/jquery.peity.min.js"></script> 
<script src="__JS__/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
