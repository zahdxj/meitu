<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:63:"E:\phpStudy\WWW\thinkphp5/application/admin\view\ad\adList.html";i:1479542920;s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479540020;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/main.css" />

</head>
<body>

<!--Header-part-->
<div id="header">
    <h1>后台管理系统</h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li id="profile-messages" >
            <a title="" href="<?php echo url('index/index'); ?>">
                <span class="glyphicon glyphicon-user white"></span>
                <span class="text white">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <span class="glyphicon glyphicon-share-alt white"></span> 
                <span class="text white">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><span class="glyphicon glyphicon-th"></span><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content" data-controller="ad" data-page="adList">
	<div id="content-header"  class="content-extra">
	  	<div id="breadcrumb"> 
	  		<a href="" title="首页" class="tip-bottom">
	  			<span class="glyphicon glyphicon-home"></span>首页
	  		</a>
	  		<a href="" class="tip-bottom">广告管理</a> 
	  		<a href="" class="current">广告列表</a> 
	  	</div>
	</div>
	<div class="content">
		<div class="content-top">
			<a class="btn btn-primary white" href="<?php echo url('addAd'); ?>" role="button">添加广告</a>
		</div>
		<table class="table table-hover table-bordered text-center" style="width: 823px">
			<tr class="bg-info">
				<td>广告名称</td>
				<td>广告位置</td>
				<td>广告链接</td>
				<td>描述</td>
				<td>是否显示</td>
				<td>操作</td>
			</tr>
			<?php if(is_array($list) || $list instanceof \think\Collection): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<tr class="bg-danger">
					<td><?php echo $vo['ad_name']; ?></td>
					<td><?php echo $vo['position_name']; ?></td>
					<td><?php echo $vo['ad_link']; ?></td>
					<td><?php echo $vo['ad_desc']; ?></td>
					<td><?php if($vo['is_show'] == '1'): ?>是<?php else: ?>否<?php endif; ?></td>
					<td>
                        <a class="font-color" href="<?php echo url('editAd',array('ad_id'=>$vo['ad_id'])); ?>">编辑</a>&nbsp;&nbsp;
						<a class="font-color" onclick="deleteElement('<?php echo url('delAd'); ?>','<?php echo $vo['ad_id']; ?>','ad_id')" href="javascript:;">删除</a>
					</td>
				</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</table>
		<div class="page">
			<?php echo $page; ?>
		</div>
	</div>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">技术支持：南京微沐软件科技有限公司</div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/common.js"></script> 
</body>
</html>
