<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:67:"E:\phpStudy\WWW\thinkphp5/application/home\view\member\collect.html";i:1479803769;s:64:"E:\phpStudy\WWW\thinkphp5/application/home\view\public\base.html";i:1479804427;}*/ ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=3, minimum-scale=1, user-scalable=no">
<meta name="format-detection" content="email=no"/>
<title>美图商城</title>
<link href="__HOME__/css/weui.css" rel="stylesheet" type="text/css" />
<link href="__HOME__/css/home.css" rel="stylesheet" type="text/css" />
</head>
<body ontouchstart>


<div class="container" data-controller="member" data-page="collect" style="margin: 0; display: initial;">
	<div class="ui_collect_hd">
		<header id="header" class="ui_header">
			收藏足迹
			<a id="link_edit">编辑</a>
		</header><!-- /header -->
		<div class="ui_tab ui_tab_collect">
			<div data-panel="mycollect" class="ui_tab_hd active">我的收藏</div>
			<div data-panel="myhistory" class="ui_tab_hd">我的足迹</div>
		</div>
	</div>
	<div class="ui_collect_bd">
		<!-- 我的收藏 panel -->
		<div class="ui_panel ui_panel_collect" id="mycollect">
			<ul>
                <?php if(is_array($collect_list) || $collect_list instanceof \think\Collection): $i = 0; $__LIST__ = $collect_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li>
					<div class="ui_collect_btn" data-id="<?php echo $vo['goods_id']; ?>" data-type="0"><img src="__HOME__/images/del.png" alt=""></div>
					<a href="<?php echo url('Goods/goods_info',array('goods_id'=>$vo['goods_id'])); ?>" title="">
						<div class="ui_collect_img"><img src="__PUBLIC__/<?php echo $vo['goods_thumb']; ?>" alt=""></div>
	                    <div class="ui_collect_desc"><?php echo $vo['goods_name']; ?></div>
                    </a>
				</li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			<div class="JQ_pagination pagination_mycollect"></div>
		</div>
		<!-- / 我的收藏 panel -->
		<!-- 我的足迹 panel -->
		<div class="ui_panel ui_panel_collect" id="myhistory">
			<ul>
                <?php if(is_array($trace_list) || $trace_list instanceof \think\Collection): $i = 0; $__LIST__ = $trace_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<li>
					<div class="ui_collect_btn" data-id="<?php echo $vo['goods_id']; ?>" data-type="1"><img src="__HOME__/images/del.png" alt=""></div>
					<a href="<?php echo url('Goods/goods_info',array('goods_id'=>$vo['goods_id'])); ?>" title="">
						<div class="ui_collect_img"><img src="__PUBLIC__/<?php echo $vo['goods_thumb']; ?>" alt=""></div>
						<div class="ui_collect_desc"><?php echo $vo['goods_name']; ?></div>
					</a>
				</li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			<div class="JQ_pagination pagination_myhistory"></div>
		</div>
		<!-- / 我的足迹 panel -->
	</div>
</div>


<!-- footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_default">
    <a href="<?php echo url('index/index'); ?>" class="weui_tabbar_item" id="nav_index">
        <div class="weui_tabbar_icon icon_home"></div>
        <p class="weui_tabbar_label">首页</p>
    </a>
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item" id="nav_contact">
        <div class="weui_tabbar_icon icon_contact"></div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item" id="nav_member">
        <div class="weui_tabbar_icon icon_user"></div>
        <p class="weui_tabbar_label">我的</p>
    </a>
    <a href="<?php echo url('About/aboutus'); ?>" class="weui_tabbar_item" id="nav_about">
        <div class="weui_tabbar_icon icon_about"></div>
        <p class="weui_tabbar_label">关于我们</p>
    </a>
</div>
<!-- 详情页面footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_primary hide">
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/chat.png"/>
        </div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a class="weui_btn weui_btn_default" href="javascript:;" id="showToast">加入收藏夹</a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/star.png"/>
        </div>
        <p class="weui_tabbar_label">收藏夹</p>
    </a>
    <!--BEGIN toast-->
    <div id="toast" style="display: none;">
        <div class="weui_mask_transparent"></div>
        <div class="weui_toast"></div>
    </div>
    <!--end toast-->
</div>
<script src="__HOME__/js/jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/swiper-3.4.0.jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/common.js" type="text/javascript"></script>


<script src="__HOME__/js/jquery.page.js" type="text/javascript"></script>
<script type="text/javascript">
$(function(){
	//初始化分页
	JQpage('mycollect',1,0);
	JQpage('myhistory',1,0);

	//tab
	$('#myhistory').add('.ui_collect_btn').hide();
	$('.ui_tab_collect').on('click', '.ui_tab_hd', function () {
		$('.ui_tab_hd').removeClass('active');
		$(this).addClass('active');
		var panel = $(this).attr('data-panel');
		$('.ui_panel').hide();
		$('#' + panel).show();
		$('#link_edit').html('编辑');
		$('.ui_collect_btn').hide();
		//获取页数
		var curpage = $('.pagination_'+panel).find('.current').text();
		JQpage(panel,curpage,1);
	})

	//编辑按钮
	$('#link_edit').click(function(){
		if ($(this).text() == '编辑') {
			var panelId;
			$(this).html('完成');
			$('.ui_tab_hd').each(function() {
				if ($(this).hasClass('active')) {
					panelId = $(this).attr('data-panel');
				}
			});
			$('#' + panelId).find('.ui_collect_btn').toggle(500);
		} else {
			$(this).html('编辑');
			$('.ui_collect_btn').toggle(500);
		}
	})

	//删除
	$('.ui_collect_bd').on('click', '.ui_collect_btn', function () {
		var type = $(this).attr('data-type');	//0-收藏，1-足迹
		var goods_id = $(this).attr('data-id');
		var e = $(this).parent();
		$.post("<?php echo url('Member/del'); ?>", {'goods_id':goods_id,'type':type} , function(data){
			data = $.parseJSON(data);
			if (data.error == 0) {
				e.fadeTo("slow", 0.01, function(){
					$(this).slideUp("slow", function() {
						$(this).remove();
					});
				});
			} else {
				JAlert(data.info);
			}
		},'json')
	})
})

//jquery 分页
//pagename: panel名称
//curpage: 当前页
//type: 0-初次加载
function JQpage(pagename,curpage,type){
	console.log(curpage)
	var total = $('#'+pagename).find('li').length;
	var pageCount = 1;
	var n = 2;
	if (type == 0) {
		pageShow(pagename,n,1);
	}
	if (parseInt(total%n) == 0) {
		pageCount = parseInt(total/n);
	} else {
		pageCount = parseInt(total/n) + 1;
	}
    $(".pagination_"+pagename).createPage({
        pageCount:pageCount,
        current:curpage,
        backFn:function(p){
            pageShow(pagename,n,p);
        }
    });
}
//set page
//pagename: panel名称
//n: 每页显示数量
//curpage: 当前页
function pageShow(pagename,n,curpage){
    $('#'+pagename).find('li').each(function(index,ele){
    	if (index >= n*(curpage-1) && index < n*curpage) {
    		$('#'+pagename).find('li').eq(index).show();
    	} else {
    		$('#'+pagename).find('li').eq(index).hide();
    	}
    })
}
</script>

</body>
</html>