<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"D:\phpStudy\WWW\thinkphp5\public/../application/admin\view\login\index.html";i:1478656827;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>登录</title>
</head>
<style>
	body{
/*		background-image:url(../../../static/oldAdmin/images/16sucai_201405121821.jpg);*/
background-image:url(__PUBLIC__/static/oldAdmin/images/16sucai_201405121821.jpg);
		}
	.lz_lgoindiv{
		width:300px;
		margin-left:600px;
		margin-top:200px;
		}	
	.lz_login{
	font-family: "黑体";
	color: #666;
	text-align: left;
}	
	.img{
		cursor:pointer;
	}
	.lz_login_yz{
		margin-top:10px;}
	.lzimg{
		margin-top:10px;}
	.lzdiv{
		width:30px;
		height:30px;}
	table th{
		text-align:right;
	}	
</style>
<body>
<div class="lz_logindivlz">
<div class="lz_lgoindiv">
<h2>189比一比后台管理系统</h2>
<form action="<?php echo url('Login/do_login'); ?>" method="post" >
    <table class="lz_login">
     <tr><th>用户名:</th><td><input type="text" name="user_name" /></td></tr>
		<tr><th>密码:</th><td><input type="password" name="password" /></td></tr>
		<tr><th height="37"></th><td><input type="submit" name="submit" value="登录"/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" name="reset" value="重置"/></td></tr>
    </table>
    </form>
</div>
</div>

</body>
</html>
