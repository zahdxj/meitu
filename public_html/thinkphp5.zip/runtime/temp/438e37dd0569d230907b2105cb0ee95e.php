<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:63:"E:\phpStudy\WWW\thinkphp5/application/admin\view\goods\add.html";i:1479695707;s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479694667;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/main.css" />

<link rel="stylesheet" href="__STATIC__/kindeditor/plugins/code/prettify.css" />

</head>
<body>

<!--Header-part-->
<div id="header">
    <h1>后台管理系统</h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li id="profile-messages" >
            <a title="" href="<?php echo url('index/index'); ?>">
                <span class="glyphicon glyphicon-user white"></span>
                <span class="text white">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <span class="glyphicon glyphicon-share-alt white"></span> 
                <span class="text white">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><span class="glyphicon glyphicon-th"></span><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content" data-controller="goods" data-page="add">
	<div id="content-header" class="content-extra">
		<div id="breadcrumb"> 
			<a href="" title="首页" class="tip-bottom">
				<span class="glyphicon glyphicon-home"></span>首页
			</a> 
			<a href="" class="tip-bottom">商品管理</a> 
			<span class="current"><?php echo $title; ?></span> 
		</div>
	</div>
	<div class="content">
		<div class="content-top">
			<a class="btn btn-primary white"  href="<?php echo url('index'); ?>" role="button">商品列表</a>
		</div>
	</div>
	<div class="content-left">		
    	<form action="" method="post" name="addform" enctype="multipart/form-data" onsubmit="return checkform()" role="form" class="form-horizontal">
    		<div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品名称：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="text" name="goods_name" class="form-control" value="<?php if(isset($goods_info)): ?><?php echo $goods_info['goods_name']; endif; ?>"/>
		      	</div>
		      	<span id="sp1" style="color:red;" class="col-sm-offset-3 col-sm-9"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品分类：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<select name="cat_id" class="form-control">
						<option value="">请选择分类...</option>
						<?php if(is_array($cat_list) || $cat_list instanceof \think\Collection): $i = 0; $__LIST__ = $cat_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<option value="<?php echo $vo['cat_id']; ?>" <?php if(isset($goods_info) && $vo['cat_id'] == $goods_info['cat_id']): ?>selected<?php endif; ?> ><?php echo returnspace($vo['level']); ?><?php echo $vo['cat_name']; ?></option>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</select>
		      	</div>
		      	<span id="sp2" style="color:red;" class="col-sm-offset-3 col-sm-9"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品图片：</label>
		    	</div>
		    	<div class="col-sm-9" id="goods_img_box">
                    <?php if(isset($goods_info['goods_img'])): if(is_array($goods_info['goods_img']) || $goods_info['goods_img'] instanceof \think\Collection): $i = 0; $__LIST__ = $goods_info['goods_img'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$img): $mod = ($i % 2 );++$i;?>
                        <div class="col-sm-6 goods_img_item" id="goods_img_<?php echo $key; ?>">
                            <div id="imgdiv_<?php echo $key; ?>"><img id="imgShow_<?php echo $key; ?>" width="150" height="150" onclick="$('#up_img_<?php echo $key; ?>').click()" src="__PUBLIC__/<?php echo $img['img_url']; ?>"><div class="delete_btn" onclick="delete_img('<?php echo $key; ?>')"></div></div><input class="img_input" type="file" id="up_img_<?php echo $key; ?>" name="goods_img[]">
                        </div>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        <div class="col-sm-6 goods_img_item" id="goods_img_<?php echo $img_count; ?>">
                            <div id="imgdiv_<?php echo $img_count; ?>"><img id="imgShow_<?php echo $img_count; ?>" width="150" height="150" onclick="$('#up_img_<?php echo $img_count; ?>').click()" src="__IMAGES__/plus.jpg" /></div><input class="img_input" type="file" id="up_img_<?php echo $img_count; ?>" name="goods_img[]" />
                        </div>
                    <?php else: ?>
                        <div class="col-sm-6 goods_img_item" id="goods_img_0">
                            <div id="imgdiv_0"><img id="imgShow_0" width="150" height="150" onclick="$('#up_img_0').click()" src="__IMAGES__/plus.jpg" /></div><input class="img_input" type="file" id="up_img_0" name="goods_img[]" />
                        </div>
                    <?php endif; ?>
                    <input type="hidden" name="img_count" value="<?php echo $img_count; ?>">
		      	</div>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品描述：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<textarea style="resize:none;" rows="3" cols="20" name="goods_desc" class="form-control"><?php if(isset($goods_info)): ?><?php echo $goods_info['goods_desc']; endif; ?></textarea>
		      	</div>
		      	<span id="sp3" style="color:red;" class="col-sm-offset-3 col-sm-9"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品详情：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<textarea id="notice" name="goods_info" style="width:700px;height:300px;"><?php if(isset($goods_info)): ?><?php echo $goods_info['goods_info']; endif; ?></textarea>
		      	</div>
		      	<span id="sp4" style="color:red;" class="col-sm-offset-3 col-sm-9"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品库存：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="text"  name="goods_number" value="<?php if(isset($goods_info)): ?><?php echo $goods_info['goods_number']; endif; ?>" class="form-control" />
		      	</div>
		      	<span id="sp3" style="color:red;" class="col-sm-offset-3 col-sm-9"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品价格：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="text"  name="goods_price" value="<?php if(isset($goods_info)): ?><?php echo $goods_info['goods_price']; endif; ?>" class="form-control" />
		      	</div>
		      	<span id="sp4" style="color:red;" class="col-sm-offset-3 col-sm-9"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">商品排序：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="text"  value="<?php if(isset($goods_info)): ?><?php echo $goods_info['sort']; endif; ?>" name="sort" class="form-control" />
		      	</div>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">是否上架：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<label class="radio-inline">
					  	<input type="radio" name="is_on_sale" value="1" <?php if((isset($goods_info) && $goods_info['is_on_sale'] == 1) or !isset($goods_info)): ?>checked<?php endif; ?>/>是
					</label>
					<label class="radio-inline">
					  	<input type="radio" name="is_on_sale" value="0" <?php if(isset($goods_info) && $goods_info['is_on_sale'] == 0): ?>checked<?php endif; ?>/>否
					</label>
		      	</div>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">是否首页展示：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<label class="radio-inline">
					  	<input type="radio" name="is_show_index" value="1" <?php if((isset($goods_info) && $goods_info['is_show_index'] == 1) or !isset($goods_info)): ?>checked<?php endif; ?>/>是
					</label>
					<label class="radio-inline">
					  	<input type="radio" name="is_show_index" value="0" <?php if(isset($goods_info) && $goods_info['is_show_index'] == 0): ?>checked<?php endif; ?>/>否
					</label>
		      	</div>
		    </div>
		    <div class="form-group login-margin">
			    <div class="col-sm-offset-3 col-sm-9">
                    <?php if(isset($goods_info)): ?>
                        <button class="btn btn-primary" type="submit" id="submit" name="submit">确定</button>
                    <?php else: ?>
                        <button class="btn btn-primary" type="submit" id="submit" name="submit">添加</button>
                    <?php endif; ?>
			        <button class="btn btn-white" type="reset"  style="margin-left: 20px;">重置</button>
			    </div>
			</div>
        </form>
    </div>
</div>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">技术支持：南京微沐软件科技有限公司</div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/common.js"></script> 


<script charset="utf-8" src="__STATIC__/kindeditor/kindeditor.js"></script>
<script charset="utf-8" src="__STATIC__/kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="__JS__/uploadPreview.js"></script>
<script charset="utf-8" src="__JS__/goods.js"></script>

</body>
</html>