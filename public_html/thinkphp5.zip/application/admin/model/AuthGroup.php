<?php

/* 
 * 用户组模型
 */
namespace app\admin\model;
use app\common\model\Base;

class AuthGroup extends Base{
    
    
}
