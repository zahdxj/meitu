<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:66:"D:\phpStudy\WWW\thinkphp5/application/admin\view\group\access.html";i:1479087780;s:65:"D:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479118911;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/colorpicker.css" />
<link rel="stylesheet" href="__CSS__/datepicker.css" />
<!-- <link rel="stylesheet" href="__CSS__/uniform.css" />
<link rel="stylesheet" href="__CSS__/select2.css" /> -->
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-wysihtml5.css" />
<link href="__CSS__/font-awesome/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="__CSS__/main.css" />
<!--<script src="__JS__/jquery.js"></script>--> 
</head>
<body>

<!--Header-part-->
<div id="header">
    <h1><a href="dashboard.html">后台</a></h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li  class="dropdown" id="profile-messages" >
            <a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle">
                <i class="icon icon-user"></i>  
                <span class="text">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
                <li>
                    <a href="">
                    <i class="icon-user"></i>个人资料</a>
                </li>
                <li class="divider"></li>
                <li>
                    <a href="<?php echo url('login/logout'); ?>">
                    <i class="icon-key"></i>退出
                    </a>
                </li>
            </ul>
        </li>
        <li class="">
            <a title="" href="" target="_blank">
                <i class="icon icon-cog"></i> 
                <span class="text">网站首页</span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <i class="icon icon-share-alt"></i> 
                <span class="text">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><i class="icon icon-th"></i><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content">
	<div id="content-header">
  		<div id="breadcrumb"> 
  			<a href="" title="首页" class="tip-bottom">
  				<span class="glyphicon glyphicon-home"></span>首页
  			</a>
  			<a href="" class="tip-bottom">管理员管理</a> 
  			<a href="" class="current">权限列表</a> 
  		</div>
  		<h1>权限节点</h1>
	</div>
	<div class="content">
		<div class="content-top">
			<a class="btn btn-primary white" href="<?php echo url('addNode'); ?>" role="button">
				<strong><span class="glyphicon glyphicon-plus"></span>添加节点</strong>
			</a>
		</div>
		<table class="table table-hover table-bordered text-center" style="width: 823px">
			<tr class="bg-info">
				<td>ID</td>
				<td>名称</td>
				<td>标识</td>
				<td>分组</td>
				<td>状态</td>
				<td>操作</td>
			</tr>
			<?php if(is_array($list) || $list instanceof \think\Collection): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<tr class="bg-danger">
					<td><?php echo $vo['id']; ?></td>
					<td><?php echo $vo['title']; ?></td>
					<td><?php echo $vo['name']; ?></td>
					<td><?php echo $vo['group']; ?></td>
                    <td><?php if($vo['status'] == 1): ?>启用<?php else: ?>禁用<?php endif; ?></td>
					<td>
                        <a class="font-color"  href="<?php echo url('Group/editNode',array('id'=>$vo['id'])); ?>">编辑</a>&nbsp;&nbsp;
						<a  class="font-color" href="javascript:;" onclick="delNode('<?php echo $vo['id']; ?>')">删除</a>&nbsp;&nbsp;
					</td>
				</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</table>
	</div>
</div>
<script type="text/javascript">
	function delNode(id){
        var url="<?php echo url('Group/delNode'); ?>";
		if(confirm("确定删除此节点吗?")){
			location.href=url+"?id="+id;
		}
	}
</script>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">  2014 &copy;出自LZ之手 </div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/jquery.ui.custom.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/bootstrap-colorpicker.js"></script> 
<script src="__JS__/bootstrap-datepicker.js"></script> 
<script src="__JS__/jquery.toggle.buttons.html"></script> 
<script src="__JS__/masked.js"></script> 
<script src="__JS__/jquery.uniform.js"></script> 
<script src="__JS__/select2.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/wysihtml5-0.3.0.js"></script> 
<script src="__JS__/jquery.peity.min.js"></script> 
<script src="__JS__/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
