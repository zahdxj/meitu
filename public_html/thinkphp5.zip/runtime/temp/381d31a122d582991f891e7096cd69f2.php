<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:64:"E:\phpStudy\WWW\thinkphp5/application/home\view\about\index.html";i:1479805298;s:64:"E:\phpStudy\WWW\thinkphp5/application/home\view\public\base.html";i:1479806887;s:69:"E:\phpStudy\WWW\thinkphp5/application/home\view\public\aftersale.html";i:1479806497;}*/ ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=3, minimum-scale=1, user-scalable=no">
<meta name="format-detection" content="email=no"/>
<title>美图商城</title>
<link href="__HOME__/css/weui.css" rel="stylesheet" type="text/css" />
<link href="__HOME__/css/home.css" rel="stylesheet" type="text/css" />
</head>
<body ontouchstart>


<div class="container" data-controller="about" data-page="index" style="margin: 0; display: initial;">
	<div class="ui_page_hd">
		<ul>
			<li data-panel="contactus" class="active">联系我们</li>
			<li data-panel="buy">如何购买</li>
			<li data-panel="aftersale">售后服务</li>
			<li data-panel="followus">关注我们</li>
		</ul>
	</div>
	<div class="ui_page_bd">
		<!-- 联系我们 panel -->
		<div class="weui_panel" id="contactus">
			<div class="ui_contactus">
        		<div class="weui_panel_hd">
					<div class="ui_col_2">公司地址 Address</div>
					<div class="ui_col_2"><img src="__HOME__/images/tel.png" alt=""> 400-888-7189</div>
        		</div>
		        <div class="weui_panel_bd">
		            <div class="weui_media_box weui_media_appmsg">
		                <div class="weui_media_hd">
		                    <img class="weui_media_appmsg_thumb" src="__HOME__/images/ljlogo.png" alt="">
		                </div>
		                <div class="weui_media_bd">
		                    <h4 class="weui_media_title">江苏良晋</h4>
		                    <p class="weui_media_desc">江苏省南京紫东国际创意园A4栋6楼</p>
		                </div>
		            </div>
		        </div>
			</div>
		</div>
		<!-- / 联系我们 panel -->
		<!-- 如何购买 panel -->
		<div class="weui_panel" id="buy">
			<div class="ui_buy">
        		<div class="weui_panel_hd">
					购买方式 Way to buy
        		</div>
		        <div class="weui_panel_bd">
		            <div class="weui_media_box weui_media_appmsg">
		                <div class="weui_media_hd">
		                    <img class="weui_media_appmsg_thumb" src="__HOME__/images/ljlogo.png" alt="">
		                </div>
		                <div class="weui_media_bd">
		                    <h4 class="weui_media_title"><font color="#e92076">Online</font></h4>
		                    <p class="weui_media_desc"><font color="#e92076" size="4">微信购买</font></p>
		                </div>
		            </div>
		        </div>
                <div class="weui_panel_fd">
                	选择满意宝贝后，点击联系微信客服，添加我们的微信客服账号，取得联系后购买。
                </div>
		        <div class="weui_panel_bd">
		            <div class="weui_media_box weui_media_appmsg">
		                <div class="weui_media_hd">
		                    <img class="weui_media_appmsg_thumb" src="__HOME__/images/ljlogo.png" alt="">
		                </div>
		                <div class="weui_media_bd">
		                    <h4 class="weui_media_title"><font color="#e92076">Online</font></h4>
		                    <p class="weui_media_desc"><font color="#e92076" size="4">在线咨询购买</font></p>
		                </div>
		            </div>
		        </div>
                <div class="weui_panel_fd">
                	选择满意宝贝后，点击联系微信客服，选择在线咨询购买。
                </div>
		        <div class="weui_panel_bd">
		            <div class="weui_media_box weui_media_appmsg">
		                <div class="weui_media_hd">
		                    <img class="weui_media_appmsg_thumb" src="__HOME__/images/ljlogo.png" alt="">
		                </div>
		                <div class="weui_media_bd">
		                    <h4 class="weui_media_title"><font color="#e92076">Online</font></h4>
		                    <p class="weui_media_desc"><font color="#e92076" size="4">电话订购</font></p>
		                </div>
		            </div>
		        </div>
                <div class="weui_panel_fd">
                	您在美粉俱乐部上看到心仪的宝贝后，可电话联系下单。<br />
                	订购热线：025-58771566转802  <br />
                	客服热线：400-888-7189
                </div>
			</div>
		</div>
		<!-- / 如何购买 panel -->
		<!-- 售后服务 panel -->
		<div class="weui_panel" id="aftersale">
			<div class="aftersale_file">
	<div class="ui_cell">
		<h3>店铺服务详情：</h3>
		<p>1、行货正品</p>
		<p>我们销售的所有手机均为大陆正品行货，均有正规发票和官方三包卡，遵循国家质量三包法。如您对此不放心，可在收到手机后至当地品牌官方售后进行手机鉴定，然后再确认收货。</p>
		<p>2、全国三包</p>
		<p>我们销售的所有手机严格执行国家质量三包政策，所销售的所有手机三包有效期限为一年，附件三包有效期为电池六个月、充电器一年、外界有线耳机三个月。</p>
		<p>3、质保专用章</p>
		<p>良晋数码推出质保转印章服务，转印章操作流程：将质保章撕下，贴于三包凭证用户联（购机商店盖章）处，使劲挤压后，将表层膜撕下即可；</p>
		<p>4、正规发票</p>
		<p>发票均为正规机打发票，卖家可以登录财税网进行查询。</p>
	</div>
	<div class="ui_cell">
		<h3>常见问题：</h3>
		<p>1、我选择的这款商品有货吗？什么时候能发货？</p>
		<p>您好，网上可以下单的产品一般都是有货的，一般在当天16点之前付款的订单可以当天发货，最迟在72小时内完成发货。注明“预售”的产品会根据产品详情页说明的发货时间提早或者准时发货。</p>
		<p>2、如果没有按照承诺发货我该怎么办？</p>
		<p>您好，此类情况属于延迟发货，按规定从买家付款后，凡是72小时内未发货的，定制、预售及其他特殊情形等另行约定发货时间的商品除外，属妨害买家购买权益的行为，商家需向买家作出一定的补偿，详情请咨询本店客服。</p>
		<p>3、我买的商品发货后多久能到？运输安全吗？</p>
		<p>您好，一般视不同的区域，到货时间会有所差异，请根据页面的预计到达时效评估到货时间。我们默认发顺丰快递，顺丰不到的地方发EMS或者圆通，顺丰快递发江浙沪正常情况下1-2天左右，其它地区3-7天左右；邮政EMS大致3-7天左右，节假日或边远地区等特殊情况下可能会多耗费几个工作日。如快递过程中出现丢件现象，我们会第一时间联系客户，立刻重新发货。本店暂未开通港、台、澳以及海外的订单发货。关于商品的运输，在快递接受前我们一般都会仔细包装，加足防护措施，所以在没有自然灾害等特殊情况下，运输是安全的，请放心。</p>
		<p>4、发票和商品同一时期寄出吗？如不是，我该如何追踪发票物流？</p>
		<p>您好，本店在发货时，一般都是发票和商品同行，在签收时，请在第一时间确认是否收到发票。如果您确认没有，请在第一时间联系客服。由于特殊原因暂未收到发票的，客服一般都会提前告知，并会在补寄发票的时候，留下可以查询跟踪的物流单号。</p>
		<p>5、该怎么收货，应该注意哪些事项？</p>
		<p>您好，在您签收包裹时，务必当快递员面本人签收，如授权他人代签，视同本人签收；为了保障您的最大权益，签收时请一定要确认包裹上是有良晋数码标志，并请当快递员面拆开包裹检查配件是否齐全，手机是否有外壳破损等现象，如有问题请拒签，并在第一时间联系我们的客服。</p>
		<p>6、15天以后的质量问题该如何处理？</p>
		<p>您好，在您购买商品的15天后，如果产品出现质量问题，请带上发票和保修卡，去当地厂商官方售后服务中心处理售后；如果当地无官方售后服务中心，可联系我们的客服，寄回我们代为检修。</p>
		<p>7、购买之后价格降低怎么办？</p>
		<p>您好，电子产品价格波动属于正常，请以购买时的价格为准，本店不支持价格补偿，敬请谅解。</p>
	</div>
	<div class="ui_cell">
		<h3>签收验货说明：</h3>
		<p><img src="__HOME__/images/q_signed.png" alt=""></p>
	</div>
	<div class="ui_cell">
		<h3>售后问题说明：</h3>
		<p><img src="__HOME__/images/q_after.png" alt=""></p>
	</div>
</div>
		</div>
		<!-- / 售后服务 panel -->
		<!-- 关注我们 panel -->
		<div class="weui_panel" id="followus">
			<div class="ui_followus">
				<p>长按识别二维码关注我们</p>
				<ul>
					<li>
						<img src="__HOME__/images/qrcode_for_mt.jpg" alt="">
						<p>欢迎关注<font color="#e92076">美粉俱乐部</font>，服务号：<font color="#e92076">meituclub</font>,有任何问题请留言！</p>
					</li>
					<li>
						<img src="__HOME__/images/qrcode_for_smsc.jpg" alt="">
						<p>欢迎关注<font color="#e92076">良晋数码商城</font>，服务号：<font color="#e92076">liangjin3C</font>,有任何问题请留言！</p>
					</li>
					<li>
						<img src="__HOME__/images/qrcode_for_ljzx.jpg" alt="">
						<p>欢迎关注<font color="#e92076">良晋在线</font>，服务号：<font color="#e92076">LJSJ01</font>,有任何问题请留言！</p>
					</li>
				</ul>
			</div>
		</div>
		<!-- / 关注我们 panel -->
	</div>
</div>


<!-- footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_default">
    <a href="<?php echo url('index/index'); ?>" class="weui_tabbar_item" id="nav_index">
        <div class="weui_tabbar_icon icon_home"></div>
        <p class="weui_tabbar_label">首页</p>
    </a>
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item" id="nav_contact">
        <div class="weui_tabbar_icon icon_contact"></div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item" id="nav_member">
        <div class="weui_tabbar_icon icon_user"></div>
        <p class="weui_tabbar_label">我的</p>
    </a>
    <a href="<?php echo url('About/aboutus'); ?>" class="weui_tabbar_item" id="nav_about">
        <div class="weui_tabbar_icon icon_about"></div>
        <p class="weui_tabbar_label">关于我们</p>
    </a>
</div>
<!-- 详情页面footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_primary hide">
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/chat.png"/>
        </div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a class="weui_btn weui_btn_default" href="javascript:;" id="showToast">加入收藏夹</a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/star.png"/>
        </div>
        <p class="weui_tabbar_label">收藏夹</p>
    </a>
    <!--BEGIN toast-->
    <div id="toast" style="display: none;">
        <div class="weui_mask_transparent"></div>
        <div class="weui_toast"></div>
    </div>
    <!--end toast-->
</div>
<div class="fixed-rb" id="gotop">
    <i class="gotop"></i>
</div>
<script src="__HOME__/js/jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/swiper-3.4.0.jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/common.js" type="text/javascript"></script>


<script type="text/javascript">
$(function(){
	$('#buy').add('#aftersale').add('#followus').hide();
	$('.ui_page_hd').on('click', 'li', function () {
		$('.ui_page_hd').find('li').removeClass('active');
		$(this).addClass('active');
		var panel = $(this).attr('data-panel');
		$('.weui_panel').hide();
		$('#' + panel).show();
	})
})
</script>

</body>
</html>