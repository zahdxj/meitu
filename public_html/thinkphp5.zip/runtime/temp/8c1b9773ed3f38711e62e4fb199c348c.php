<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:66:"E:\phpStudy\WWW\thinkphp5/application/home\view\goods\contact.html";i:1479780391;s:64:"E:\phpStudy\WWW\thinkphp5/application/home\view\public\base.html";i:1479804427;s:67:"E:\phpStudy\WWW\thinkphp5/application/home\view\public\contact.html";i:1479548245;}*/ ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=3, minimum-scale=1, user-scalable=no">
<meta name="format-detection" content="email=no"/>
<title>美图商城</title>
<link href="__HOME__/css/weui.css" rel="stylesheet" type="text/css" />
<link href="__HOME__/css/swiper-3.4.0.min.css" rel="stylesheet" type="text/css" />
<link href="__HOME__/css/home.css" rel="stylesheet" type="text/css" />
</head>
<body ontouchstart>
	<div class="ui_fixed">
	    <div class="weui_cell ui_navbar">
            <div class="weui_cell_hd">
                <img src="__HOME__/images/category.png" id="show"/>
                <span class="category">分类</span>
            </div>
            <div class="weui_cell_bd weui_cell_primary">
                <div class="weui_search_bar" id="search_bar">
                    <form class="weui_search_outer" action="<?php echo url('Goods/goods_list'); ?>" method="get" name="searchForm">
                        <div class="weui_search_inner">
                            <input type="search" name="keywords" class="weui_search_input" id="search_input" placeholder="搜索你想要的商品名称" required/>
                            <img src="__HOME__/images/search.png" onclick="submitForm()"/>
                        </div>
                    </form>
                </div>
            </div>
        </div>
	</div>
	<div class="mask"></div>
	<div class="weui_cells ui_animate">
        <?php if(is_array($cat_list) || $cat_list instanceof \think\Collection): $i = 0; $__LIST__ = $cat_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <a href="<?php echo url('Goods/goods_list',array('cat_id'=>$vo['cat_id'])); ?>" class="weui_cell">
            <div class="weui_cell_bd weui_cell_primary">
                <p><?php echo $vo['cat_name']; ?></p>
            </div>
        </a>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>


<div class="container" data-controller="contact" data-page="index">
	<div class="mt10">
        <!-- 客服部分 -->
<div class="ui_cell" align="center">
	<p>热线电话：<font color="#e92076">400-888-7189</font>（点击拨打）</p>
</div>
<!-- 客服二维码列表 -->
<div class="ui_cell ui_qrcodes">
    <?php if(is_array($contact_list) || $contact_list instanceof \think\Collection): $i = 0; $__LIST__ = $contact_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
	<div class="ui_col_3">
		<div class="ui_qrcodes_e">
			<img src="__PUBLIC__/<?php echo $vo['weixin_img']; ?>" alt="">
			<p><?php echo $vo['contact_name']; ?></p>
		</div>
	</div>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<!-- 广告 -->
<div class="ui_cell">
	<a href="<?php echo $ad2['ad_link']; ?>" title=""><img src="__PUBLIC__/<?php echo $ad2['ad_img']; ?>" alt=""></a>
</div>
<!-- / 客服部分 -->
	</div>
</div>


<!-- footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_default">
    <a href="<?php echo url('index/index'); ?>" class="weui_tabbar_item" id="nav_index">
        <div class="weui_tabbar_icon icon_home"></div>
        <p class="weui_tabbar_label">首页</p>
    </a>
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item" id="nav_contact">
        <div class="weui_tabbar_icon icon_contact"></div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item" id="nav_member">
        <div class="weui_tabbar_icon icon_user"></div>
        <p class="weui_tabbar_label">我的</p>
    </a>
    <a href="<?php echo url('About/aboutus'); ?>" class="weui_tabbar_item" id="nav_about">
        <div class="weui_tabbar_icon icon_about"></div>
        <p class="weui_tabbar_label">关于我们</p>
    </a>
</div>
<!-- 详情页面footer -->
<div class="weui_tabbar ui_bottom_nav ui_bottom_primary hide">
    <a href="<?php echo url('Goods/contact'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/chat.png"/>
        </div>
        <p class="weui_tabbar_label">客服</p>
    </a>
    <a class="weui_btn weui_btn_default" href="javascript:;" id="showToast">加入收藏夹</a>
    <a href="<?php echo url('Member/collect'); ?>" class="weui_tabbar_item">
        <div class="weui_tabbar_icon">
            <img src="__HOME__/images/star.png"/>
        </div>
        <p class="weui_tabbar_label">收藏夹</p>
    </a>
    <!--BEGIN toast-->
    <div id="toast" style="display: none;">
        <div class="weui_mask_transparent"></div>
        <div class="weui_toast"></div>
    </div>
    <!--end toast-->
</div>
<script src="__HOME__/js/jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/swiper-3.4.0.jquery.min.js" type="text/javascript"></script>
<script src="__HOME__/js/common.js" type="text/javascript"></script>


</body>
</html>