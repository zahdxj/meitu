<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:62:"E:\phpStudy\WWW\thinkphp5/application/admin\view\user\add.html";i:1479375269;s:65:"E:\phpStudy\WWW\thinkphp5/application/admin\view\public\base.html";i:1479524424;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>shumaH5</title>
<link rel="stylesheet" href="__CSS__/bootstrap.min.css" />
<link rel="stylesheet" href="__CSS__/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="__CSS__/matrix-style.css" />
<link rel="stylesheet" href="__CSS__/matrix-media.css" />
<link rel="stylesheet" href="__CSS__/main.css" />

</head>
<body>

<!--Header-part-->
<div id="header">
    <h1>后台管理系统</h1>
</div>
<!--close-Header-part--> 
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li id="profile-messages" >
            <a title="" href="<?php echo url('index/index'); ?>">
                <span class="glyphicon glyphicon-user white"></span>
                <span class="text white">欢迎您,<?php echo \think\Session::get('admin_user_name'); ?></span>
            </a>
        </li>
        <li class="">
            <a title="" href="<?php echo url('login/logout'); ?>">
                <span class="glyphicon glyphicon-share-alt white"></span> 
                <span class="text white">退出</span>
            </a>
        </li>
    </ul>
</div>
<!--close-top-Header-menu-->
<!--sidebar-menu-->


<strong>
<!--sidebar-menu-->
<div id="sidebar">
    <a href="#" class="visible-phone"><i class="icon icon-home"></i> 首页</a>
    
    <ul class="sidebar-extra">
    <?php if(is_array($menu) || $menu instanceof \think\Collection): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
    <li class="submenu"><a href=""><span class="glyphicon glyphicon-th"></span><span><?php echo $vo['title']; ?></span></a>
    <?php if(isset($vo['block'])): ?>
    <ul style="display:block; ">
    <?php else: ?>
    <ul>
    <?php endif; if(is_array($vo['node']) || $vo['node'] instanceof \think\Collection): $i = 0; $__LIST__ = $vo['node'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url($item['name']); ?>"><?php echo $item['title']; ?></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
    </li>   
    <?php endforeach; endif; else: echo "" ;endif; ?>
   </ul>
</div>
</strong>


<div id="content">
	<div id="content-header"  class="content-extra">
  		<div id="breadcrumb"> 
  			<a href="" title="首页" class="tip-bottom">
  				<span class="glyphicon glyphicon-home"></span>首页
  			</a>
  			<a href="" class="tip-bottom">管理员管理</a> 
  			<a href="" class="current">编辑管理员</a> 
  		</div>
	</div>
	<div class="content">
		<div class="content-top">
			<a class="btn btn-primary white"  href="<?php echo url('User/index'); ?>" role="button">管理员列表</a>
		</div>
	</div>
	<div class="content-left">
		<form method="post" action="" name="addform" onsubmit="return checkform()" role="form" class="form-horizontal">
			<div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">用户名：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="text" name="user_name" value="<?php if(isset($info)): ?><?php echo $info['user_name']; endif; ?>" id="user_name" class="form-control" onblur="chkusername(this)"/>
		      	</div>
		      	<span id="sp1" style="color:red;" class="col-sm-9 col-sm-offset-3"></span>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">新密码：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="password" name="password" id="password" class="form-control" onblur="chkpwd(this)"/>
		      	</div>
		      	<span id="sp2" style="color:red;" class="col-sm-9 col-sm-offset-3"></span>
		    </div>
		    <div class="form-group login-margin">
		    	<div class="col-sm-9 col-sm-offset-3">
		    		<p class="help-block" style="font-size:13px">如留空,密码保持不变</p>
		      	</div>
		    </div>
		    <div class="form-group login-margin">
				<div class="col-sm-3">
		    		<label class="control-label">确认密码：</label>
		    	</div>
		    	<div class="col-sm-9">
		      		<input type="password" name="repassword" id="repassword" class="form-control" onblur="repwd(this)"/>
		      	</div>
		      	<span id="sp3" style="color:red;" class="col-sm-9 col-sm-offset-3"></span>
		    </div>
		    <div class="form-group login-margin">
			    <div class="col-sm-offset-3 col-sm-9">
                    <input type="hidden" name="user_id" id="user_id" value="<?php if(isset($info)): ?><?php echo $info['user_id']; endif; ?>" />
			        <button class="btn btn-primary" type="submit" name="submit">确定</button>
			        <button class="btn btn-white" type="reset" name="reset" style="margin-left: 20px;">重置</button>
			    </div>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
    function checkform(){
        var user_id=$("#user_id").val();
		if(addform.user_name.value==""){
			$("#sp1").html("用户名不能为空");
			return false;
		}
        if(user_id){
            if(addform.password.value!=''){
                var preg=/^[\w]{5,20}$/;
                if(!preg.test(addform.password.value)){
                    $("#sp2").html("密码请使用字母数字或者下划线且长度不能少于5位");
                    return false;
                }else{
                    $("#sp2").html("");
                }
            }
            if(addform.repassword.value!=addform.password.value){
                $("#sp3").html('确认密码和密码不一致');
                return fasle;
            }
            
        }else{
            if(addform.password.value==""){
                $("#sp2").html("密码不能为空");
                return false;
            }else{
                var preg=/^[\w]{5,20}$/;
                if(!preg.test(addform.password.value)){
                    $("#sp2").html("密码请使用字母数字或者下划线且长度不能少于5位");
                    return false;
                }else{
                    $("#sp2").html("");
                }
            }
            if(addform.repassword.value!=addform.password.value){
                $("#sp3").html('确认密码和密码不一致');
                return fasle;
            }
        }
		
		return true;
	}
	function chkusername(obj){
        var url="<?php echo url('User/chkusername'); ?>";
        $.post(url,{username:obj.value},function(data){
            if(data.data){
                $("#sp1").html(data.info);
            }else{
                $("#sp1").html("");
            }
        },'json');
			
	}
	function chkpwd(obj){
		var preg=/^[\w]{5,}$/;
		if(!preg.test(obj.value)){
			$("#sp2").html("密码请使用字母数字或者下划线且长度不能少于5位");
		}else{
			$("#sp2").html("");
		}
	}
    function repwd(obj){
        var pwd= $("#password").val();
        if(obj.value!=pwd){
            $("#sp3").html('确认密码和密码不一致');
        }else{
            $("#sp3").html("");
        }
    }
</script>


<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12">技术支持：南京微沐软件科技有限公司</div>
</div>
<!--end-Footer-part--> 
<script src="__JS__/jquery.min.js"></script> 
<script src="__JS__/bootstrap.min.js"></script> 
<script src="__JS__/matrix.js"></script> 
<script src="__JS__/common.js"></script> 
</body>
</html>
